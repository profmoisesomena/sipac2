// (c) ammap.com | SVG (in JSON format) map of Christmas Island - Low
// areas: {id:"CX"}
AmCharts.maps.christmasIslandLow={
	"svg": {
		"defs": {
			"amcharts:ammap": {
				"projection":"mercator",
				"leftLongitude":"105.48797",
				"topLatitude":"-10.412374",
				"rightLongitude":"105.739975",
				"bottomLatitude":"-10.570362"
			}
		},
		"g":{
			"path":[
				{
					"id":"CX",
					"title":"Christmas Island",
					"d":"M577.96,846.82L675.71,839.68L799.53,39.76L734.36,0L429.07,244.68L57.62,145.27L90.7,311.46L0.47,535.78L266.66,489.39L487.73,549.04L577.96,846.82z"
				}
			]
		}
	}
};
